App.showCenterLabel(`zep 개똥멍청이`, 0x000000, 0xFFFF00, 200, 100000);
